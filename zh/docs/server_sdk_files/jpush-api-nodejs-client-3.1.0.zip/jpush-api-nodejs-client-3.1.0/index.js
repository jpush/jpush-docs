/**
 * @author: JPush
 * @Date: 14-6-24
 * @version: 3.1.0
 */
module.exports = require('./lib/JPush/JPush.js');