require 'json'

module JPush
  class MessagesResult
    
  end
end