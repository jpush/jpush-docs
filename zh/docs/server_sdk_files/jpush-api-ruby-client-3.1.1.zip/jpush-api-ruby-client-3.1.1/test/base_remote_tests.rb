
  AppKey ="dd1066407b044738b6479275"
  MasterSecret = "2b38ce69b1de2a7fa95706ea"

  CONTENT_TYPE_JSON = "application/json"

  SUCCEED_RESULT_CODE = 0
  LACK_OF_PARAMS = 1002
  INVALID_PARAMS = 1003
  AUTHENTICATION_FAIL = 1004
  TOO_BIG = 1005
  APPKEY_NOT_EXIST = 1008
  NO_TARGET = 1011

  ALERT = "JPush Test - alert"
  MSG_CONTENT = "JPush Test - msgContent"
  TagAndMore = ["tag1", "tag_all"]
  TAG1 = ["tag1"]
  TAG2 = ["tag1", "tag2"]
  TAG3 = ["tag2"]
  TAG_ALL = ["tag_all"]
  TAG_NO = ["tag_no"]
  ALIAS1 = ["alias1"]
  ALIAS2 = ["alias1", "alias2"]
  ALIAS_NO = ["alias_no"]
  REGISTRATION_ID1 = ["0900e8d85ef"]
  REGISTRATION_ID2 = ["0900e8d85ef", "0a04ad7d8b4"]
