app_key = u'dd1066407b044738b6479275'
master_secret = u'2b38ce69b1de2a7fa95706ea'
